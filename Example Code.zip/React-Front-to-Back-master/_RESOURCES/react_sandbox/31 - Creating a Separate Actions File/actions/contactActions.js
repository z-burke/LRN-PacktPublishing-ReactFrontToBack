import { GET_CONTACTS } from './types';

export const getContacts = () => {
  return {
    type: GET_CONTACTS
  };
};
