import React from 'react';

export default () => {
  return (
    <div>
      <h1 className="display-4">404 Page Not Found</h1>
      <p>Sorry, that page does not exist</p>
    </div>
  );
};
